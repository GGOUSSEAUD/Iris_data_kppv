Les fichiers qui doivent etre dans le dossier sous les noms suivants sont:
    -iris_learn_data
    -iris_learn_label
    -iris_test_data
    -iris_test_label
    -results.txt (Il sera créé meme si vous ne le mettez pas... Il comprendra la sortie du programme)
    -alg.c
    -alg.h

P.S: Petites informations sur les méthodes utilisées dans le header (en commentaires).

Notez que le programme marche sur ma machine, si vous avez un problème, veuillez me contacter afin que je puisse vous montrer l'exécution correcte de mon programme.
Pour la compilation:
$gcc alg.c -lm
-Gaëtan GOUSSEAUD
n°13402498
